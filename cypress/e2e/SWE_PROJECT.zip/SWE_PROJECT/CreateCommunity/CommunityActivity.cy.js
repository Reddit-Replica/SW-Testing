/// <reference types="cypress" />


beforeEach(() => {

})

describe('Traffic Status Test Cases', function () {


    //Test Case 1
    it('Day', () =>  {    

    })
    
    //Test Case 2
    it('Day of the week', () =>  {    

    })
    
    //Test Case 1
    it('Month', () =>  {    

    })


})
