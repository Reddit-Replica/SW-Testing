class CommunityActivityObjects{

    Day(){
        cy.get('[id=day-button]')
            .should('have.text',"Day")
            .click()
    }

    DayOfWeek(){
        cy.get('[id=day-of-week-button]')
            .should('have.text',"Day of week")
            .click()
    }
    
    Month(){
        cy.get('[id=month-button]')
            .should('have.text',"Month")
            .click()
    }
    

}

export default CommunityActivityObjects